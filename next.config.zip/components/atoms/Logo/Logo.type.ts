export interface LogoProps {
    classNames?: string;
    src: string;
}
