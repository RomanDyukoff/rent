import type { NavItemProps } from "../NavItem/NavItem.type";

export interface NavListProps {
    classNames?: string;
    navItems: NavItemProps[];
}
