export interface ContainerProps {
    classNames?: string;
    children?: React.ReactNode;
}
