export interface CustomLinkType {
    title: string;
    href: string;
    id: string;
}
