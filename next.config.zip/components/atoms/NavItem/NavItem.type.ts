export interface NavItemProps {
    href: string;
    label: string;
}
