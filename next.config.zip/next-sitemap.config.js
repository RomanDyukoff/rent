module.exports = {
    siteUrl: "https://avtorentalvtb.by",
    generateRobotsTxt: true,
};
