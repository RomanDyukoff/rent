import img_2 from "@/public/assets/img/3afurxclwayvx5c85x91cnrxde81w3s2.png";
import img_3 from "@/public/assets/img/29dri4lxn9njhti28hlhp1k7v36j9t7f.png";
import img_4 from "@/public/assets/img/67yutraljp59feosf1ok8zzmgsyr6021.png";

export const listCards = [
    { img: img_2, alt: "2", title: "Доставка автомобиля" },
    { img: img_3, alt: "3", title: "Выдача и возврат авто 24/7" },
    { img: img_4, alt: "4", title: "Пробег без ограничений" },
];
